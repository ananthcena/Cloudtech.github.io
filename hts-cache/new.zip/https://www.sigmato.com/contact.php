    
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="author" content="Sigmato Solutions">
        <meta name="google-site-verification" content="C9wYurFuKlg9qgPfroBnX8Gjj8YFPbT52pLrilBb6nE" />
        <title>Contact Us - Creative Digital Agency Bangalore </title>
        <meta name="description" content="Bangalore based Creative Digital Agency offering professional services which include Web design & development, Web Application Development services. SEO, digital marketing, Creative designs, logos, brochures etc. Contact us now to find out more.">
        <meta name="keywords" content="Digital marketing agency,Digital agency in banaglore , web development company india, seo company, advertising agencies in india, seo agency india, digital marketing companies in india.">
        <!--   Open Graph Markup Facebook   -->
        <meta property="og:url" content="http://www.sigmato.com" />
        <meta property="og:type" content="article" />
        <meta property="og:title" content="Sigmato Solutions - Web Designing Company Bangalore, Graphics Designing Company Bangalore" />
        <meta property="og:description" content="Sigmato Solutions - Website Design Company Bangalore, Digital Marketing Company Bangalore, SEO Services Bangalore, Logo Designing Bangalore, Social media Marketing Banglore. " />
        <meta property="og:image" content="http://sigmato.com/images/sigmato-logo-new.png" />
        <!--   Open Graph Markup twitter   -->
        <meta name="twitter:card" content="Sigmato Solutions">
        <meta name="twitter:site" content="@sigmato">
        <meta name="twitter:title" content="Sigmato Solutions - Web Designing Company Bangalore, Graphics Designing Company Bangalore">
        <meta name="twitter:description" content="Sigmato Solutions - Website Design Company Bangalore, Digital Marketing Company Bangalore, SEO Services Bangalore, Logo Designing Bangalore, Social media Marketing Banglore. ">
        <meta name="twitter:creator" content="Sigmato">
        <meta name="twitter:image:src" content="http://sigmato.com/images/sigmato-logo-new.png">
        <meta name="twitter:player" content="">
        <!-- Bootstrap -->
        <link href="css/bootstrap4.min.css" rel="stylesheet">
        <!--google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700|Roboto:300,400" rel="stylesheet"> 
        <link href="https://fonts.googleapis.com/css?family=Prompt:200,300,500,700" rel="stylesheet"> 
               <!-- font awesome-->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
        <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.min.css">
        <!--custom css-->

        <link href="css/theme.css?v=2.1" rel="stylesheet">
        
        <!-- Canonical link element -->
        <link rel="canonical" href="http://www.sigmato.com/" />

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    
       <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-1C46T4X0C7"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-1C46T4X0C7');
</script>


<!-- Global site tag (gtag.js) - Google Ads: 450312349 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-450312349"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-450312349');
</script>



<script>
function gtag_report_conversion(url) {
  var callback = function () {
    if (typeof(url) != 'undefined') {
      window.location = url;
    }
  };
  gtag('event', 'conversion', {
      'send_to': 'AW-450312349/XFJ5CJmw2_QCEJ3x3NYB',
      'event_callback': callback
  });
  return false;
}
</script>



    </head>

    <body>
        

        <header class="basic-header">
            <!-- TOP TOOLBAR START-->
            <div id="toolbar" class="toolbar" style="display:none">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="toolbar-left">

                                        <div class="mobile">
                                            <i class="fa fa-phone"></i>
                                            <span class="value">+91-9880111844, +91-9611244064</span>
                                        </div>
                                        <div class="email">
                                            <i class="fa fa-envelope"></i>
                                            <a href="mailto:sigmato.web@gmail.com">info@sigmato.com</a>
                                        </div>                                       
                                        
                                        
                                    </div>
                                </div>

                                <div class="col-sm-6 top-links">
                                    <div class="social-media-top">
                                        <ul>
                                         <li  ><a href="about.php">About Us</a></li>
                                          <li><a href="/blog">Blog</a></li>
                                            <li>
                                                <a class="facebook" target="_blank" href="https://www.facebook.com/sigmato"> <i class="fa fa-facebook"></i></a>
                                            </li>
                                            <li>
                                                <a class="google-plus" target="_blank" href="https://plus.google.com/+Sigmato/posts"> <i class="fa fa-google-plus"></i></a>
                                            </li>
                                            <li>
                                                <a class="twitter" target="_blank" href="https://twitter.com/sigmatoweb"> <i class="fa fa-twitter"></i></a>
                                            </li>
                                            
                                            
                                           
                                            

                                        </ul>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- TOP TOOLBAR END-->

            <!--        nav-->
            
            
 <nav class="navbar navbar-expand-lg navbar-light bg-light">
     <div class="container">
  <a class="navbar-brand" href="index.php"> <img class="img-responsive" alt="Website Design and Development Company in Bangalore" src="images/sigmato-logo-new.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <!--<li class="nav-item active">-->
      <!--  <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>-->
      <!--</li>-->
      
        <li class="nav-item"  ><a class="nav-link" href="index.php">Home</a></li>                            
        <li class="nav-item"  ><a class="nav-link" href="design-and-user-experiences.php">Design/UX</a></li>
       <li class="nav-item"  ><a class="nav-link" href="digital_strategy_and_marketing.php">Digital Marketing</a></li>   
        <li class="nav-item" id="ser"  ><a class="nav-link" href="technology.php">Technology</a></li>
        <!--<li  ><a href="portfolio.php">Portfolio</a></li>-->
        <!--<li class="nav-item" ><a class="nav-link" href="careers.php">Careers</a></li>-->
        <li class="nav-item"class="active" ><a class="nav-link" href="contact.php">Contact</a></li>
       
        
        
        
      
      
      <!--<li class="nav-item dropdown">-->
      <!--  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">-->
      <!--    Dropdown-->
      <!--  </a>-->
      <!--  <div class="dropdown-menu" aria-labelledby="navbarDropdown">-->
      <!--    <a class="dropdown-item" href="#">Action</a>-->
      <!--    <a class="dropdown-item" href="#">Another action</a>-->
      <!--    <div class="dropdown-divider"></div>-->
      <!--    <a class="dropdown-item" href="#">Something else here</a>-->
      <!--  </div>-->
      <!--</li>-->
    </ul>
    
    <div class="ham-menu">
    <div class="ham-menu-open"><img style="width:40px" class="img-responsive" src="images/ham.png"/></div>
    <div class="ham-menu-close"><img style="width:40px" class="img-responsive" src="images/ham-close.png"/></div>
</div>


<div class="ham-menu-details" >
    
    <div class="container">
        <div class="row">
             <div class="col-md-3">
                 <div class="ham-col-1">
                       <h2>Design & User Experience</h2>
                       <ul>
                           <li><a href="#">User Experience (UX/UI)</a></li>
                           <li><a href="#">Web Interface Design</a></li>
                           <li><a href="#">Print & Graphic Design</a></li>
                           <li><a href="#">Packaging Design</a></li>
                           <li><a href="#">Product Design</a></li>
                           <img class="img-fluid" src="images/split-1.jpg"/>
                           
                       </ul>
                 </div>
                 </div>
                 
                  <div class="col-md-3">
                 <div class="ham-col-1">
                       <h2>Search Engine Optimization</h2>
                       <ul>
                           <li><a href="#">Digital Marketing</a></li>
                           <li><a href="#">Social Media Strategy</a></li>
                           <li><a href="#">Web Analytics</a></li>
                           <li><a href="#">Video Production and Marketing</a></li>
                           <li><a href="#">Marketing Automation</a></li>
                           
                       </ul>
                 </div>
                 </div>
             <div class="col-md-3">
                 <div class="ham-col-1">
                       <h2>Technology Development</h2>
                       <ul>
                           <li><a href="#">Websites & Landing Pages</a></li>
                           <li><a href="#">Content Management (CMS)</a></li>
                           <li><a href="#">MVP & Beta Development</a></li>
                           <li><a href="#">Mobile Applications</a></li>
                           <li><a href="#">Web Applications</a></li>
                           <li><a href="#">E-Commerce</a></li>
                           
                       </ul>
                 </div>
                 </div>
                  <div class="col-md-3">
                 <div class="ham-col-1">
                       <h2>Useful Links</h2>
                       <ul>
                           <li><a href="about.php">About us</a></li>
                           <li><a href="services.php">Services</a></li>
                           <li><a href="#">Case Studies</a></li>
                           <li><a href="/blog">News & Blog</a></li>
                           <li><a href="careers.php">Careers</a></li>
                           <li><a href="contact.php">Contact Us</a></li>
                         
                           
                       </ul>
                 </div>
                 </div>
      
        </div>
    </div>
    </div>







  </div>
  </div>
</nav>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>


<script>





    
$(window).scroll(function(){
    if ($(document).scrollTop() > 500) {
        if ($(".ham-menu-details").hasClass("show")) { 
       $(".ham-menu-details").removeClass('show');
       $(".ham-menu-close").hide();
       $(".ham-menu-open").show();
        }
    }
   });
   
   
$( document ).ready(function() {
   
   
   
   $(".ham-menu-open").click(function(){
       $(".ham-menu-details").addClass('show');
       $(".ham-menu-open").hide();
       $(".ham-menu-close").show();
   });
   
   
   
    $(".ham-menu-close").click(function(){
       $(".ham-menu-details").removeClass('show');
       $(".ham-menu-close").hide();
       $(".ham-menu-open").show();
       $(".ham-menu-details").removeClass('show');
       
   });
   
   
   
});
</script> 
            
            
            <style>
           .sig-offset-nav h2{font-size:18px}
            .sig-offset-nav ul{padding-left:0;margin-left:0}   
            .sig-offset-nav ul li a{font-size:14px;font-weight:400;line-height:15px}         
            .sig-offset-nav{position:fixed;width:50%;height:100%;background-color:#fff; right:-50%; z-index:999;padding-top:150px ;padding-left:50px;box-shadow: -7px 0px 10px #eaeaea; -moz-transition: all 0.5s ease;
    -o-transition: all 0.5s ease;
    transition: all 0.5s ease;
    transition-timing-function: ease;
    } 
             .sig-offset-nav ul li a{color:#333}    
             .sig-offset-nav .row{width:100%}  
             .sig-offset-nav.open{right:-0%; -moz-transition: all 0.5s ease;
    -o-transition: all 0.5s ease;
    transition: all 0.5s ease;transition-timing-function: ease;}    
            
            </style> 

        </header>
        
        
        
        
        
         <div class="featured-inner text-center">
            
            <div class="container">
              <div class="row">
                  
                    <div class="col-md-12">
                        
                         <div class="inner-page-section-header">
                 <h2 class="section-title p-tb-20 text-center">Contact us</h2>
                <h1>Get Sensible budget  and Reasonable time  frame</h1>
              
            </div>
            
             <div class="title-divider"></div>

                    </div>
                    </div>
                    
                 </div>    
                    

           
        </div>
        
        

        <section id="contact">
            <div class="container">
                <div class="row">

                    <div class="col-md-6">
                        <div class="contact-info">
                            <h3>Sigmato Solutions Pvt Ltd.</h3>
                            <p>#46, 2nd Floor, Rajini Towers
                                <br> 27th Cross Road, 7th B Main Road<br>4th Block, Jayanagar
                                <br>Bangalore - 560011,
                                <br> Karnataka, INDIA.</p>
                            <p> <span>Phone:</span>9353446451
                                <br>
                                <span>Email: </span>info@sigmato.com</p>
                            <div class="text">
                                <p>Sigmato team eagerly awaits your proposal. Just call or mail us to the above given details and we are ready to serve you. Who else can explain your business better than you? So, explain us and we take a forward-thinking approach to your business concept.</p>
                            </div>

                        </div>
                    </div>
                  <div class="col-md-6">
                        <div class="form-container">
                            <p style="margin-bottom:20px;">Please fill out the below form to contact us. Thank you.</p>

                            <form id="contact-info" method="post" action="contact-form.php" role="form">

                                <div class="messages"></div>

                                <div class="controls">

                                    <div class="form-group">

                                        <input id="contact_name" type="text" name="name" class="form-control" placeholder="Name " required="required" data-error="Name is required.">
                                        <div class="help-block with-errors"></div>

                                    </div>

                                    <div class="form-group">

                                        <input id="form_email" type="email" name="email" class="form-control" placeholder="Email ID" required="required" data-error="Valid email is required.">
                                        <div class="help-block with-errors"></div>
                                    </div>

                                    <div class="form-group">

                                        <input id="form_phone" type="text" name="phone" class="form-control" placeholder="Contact Number" required="required" data-error="Valid phone number is required.">
                                        <div class="help-block with-errors"></div>
                                    </div>

                                    <div class="form-group">

                                        <textarea id="form_message" name="message" class="form-control" placeholder="Your message or question" rows="3"></textarea>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    
                                    <!--<div class="form-group">-->
                                    <!--     Replace data-sitekey with your own one, generated at https://www.google.com/recaptcha/admin -->
                                    <!--    <div class="g-recaptcha" data-sitekey="6LeA9ogUAAAAAKqPmrKbkPTXOr3aXljsUPhbMpcu"></div>-->
                                    <!--</div>-->

                                    <input type="submit" class="btn btn-success btn-send btn-custom" value="SEND">

                                </div>
                               

                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <div id="google-map">

            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31109.641953812054!2d77.5630021015154!3d12.926656507915709!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae3e21c1151245%3A0xa32e1281a9436875!2sSigmato+Solutions+Pvt+Ltd!5e0!3m2!1sen!2sin!4v1490701004547" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>

        <!--      footer -->
        
<footer class="xs-footer-section footer-style3">
    <div class="footer-top-area">
    <div class="ft-social-icon-wrapper ax-section-gapTop">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <ul class="ft-social-share d-flex justify-content-center liststyle flex-wrap">
                                    <li><a href="https://www.facebook.com/sigmato" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="https://twitter.com/sigmatoweb" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://pinterest.com/sigmato" target="_blank"><i class="fa fa-pinterest"></i></a></li>
                                    <li><a href="https://in.linkedin.com/company/sigmato-solutions-pvt-ltd" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="https://www.instagram.com/sigmatosolutions/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                    <!--<li><a href="#"><i class="fa fa-vimeo"></i></a></li>-->
                                    <!--<li><a href="#"><i class="fa fa-dribbble"></i></a></li>-->
                                    <!--<li><a href="#"><i class="fa fa-behance"></i></a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                
			
				<div class="container">
				    
					<div class="row">
						<div class="col-md-6 col-lg-3">
							<div class="footer-widget">
								<h4 class="widget-title">Corporate Office</h4>
								<p>Address <span>#46, 2nd Floor, Rajini Towers<br>27th Cross Road, 7th B Main Road<br>4th Block, Jayanagar<br> Bangalore- 560011<br> Karnataka, INDIA</span></p>
									<h4 class="widget-title">Contact Info</h4><p>+91-9880111844<br> +91-9353446451 <a href="mailto:info@sigmato.com">info@sigmato.com</a></p>
							</div><!-- .footer-widget END -->
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="footer-widget">
								<h4 class="widget-title">Useful Links</h4>
								<ul class="xs-list footer-list">
									<li><a href="about.php">About us</a></li>
									<li><a href="services.php">Service</a></li>
									<li><a href="/blog">News &amp; Blog</a></li>
									<li><a href="contact.php">Contact Us</a></li>
									<li><a href="careers.php">Careers</a></li>
									<li><a href="#">Case Studies</a></li>
									<li><a href="https://www.sigmato.com/seo-plans.php">SEO Packages</a></li>
									<li><a href="http://sigmato.com/website-development-plans.php">Website Packages</a></li>
								
								
								</ul><!-- .xs-list END -->
							</div><!-- .footer-widget END -->
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="footer-widget">
								<h4 class="widget-title">About Us</h4>
								<ul class="xs-list footer-list">
							<li><a href="finding-the-best-web-design-agency-in-bangalore.php">Web Designing Company in Bangalore</a></li>
                            <li><a href="digital-marketing-company-bangalore.php">Digital Marketing Company in Bangalore</a></li>
                            <li><a href="graphic-designing-company-bangalore.php">Graphic Designing Company in Bangalore</a></li>
                            <li><a href="wordpress-website-development-bangalore.php">Wordpress Website Development in Bangalore</a></li>
                            <li><a href="website-design-that-can-generate-leads.php">Generate greater leads through website</a></li>
								</ul><!-- .xs-list END -->
							</div><!-- .footer-widget END -->
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="footer-widget">
								<h4 class="widget-title">Our Services</h4>
								<ul class="xs-list footer-list">
									<li><a href="webflow-web-design-development.php">Webflow Development</a></li>
									<li><a href="contact.php">Web Application</a></li>
									<li><a href="contact.php">Android Apps</a></li>
									<li><a href="contact.php">iOS Apps</a></li>
									<li><a href="contact.php">Mobile Application</a></li>
									<li><a href="contact.php">Web Development</a></li>
									<li><a href="contact.php">Corporate Service</a></li>
								</ul><!-- .xs-list END -->
							</div><!-- .footer-widget END -->
						</div>
					
					
					</div><!-- .row END -->
				</div><!-- .container END -->
			</div><!-- .footer-top-area END -->
			<div class="footer-bottom-area">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<div class="copyright-section">
								<p>Copyright 2012-2021, <a href="http://sigmato.com">Sigmato Solutions Pvt Ltd.</a> All Rights Reserved.</p>
							</div><!-- .copyright-section END -->
						</div>
						<div class="col-md-6">
							<div class="copyright-content">
							
							</div>
						</div>
					</div>
				</div>
			</div><!-- .footer-bottom-area END -->
		</footer>
		
		
		
<div class="whatsapp_action"><div class="whats_app"><a href="https://wa.me/+917349191202/" target="_blank"><img src="images/whats-app-icon.png" alt="Sigmato Solutions"></a></div></div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/validator.js"></script>
    <script src="js/contact.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src="js/theme.js"></script>
    <!--<script src="js/jQuery.scrollSpeed.js"></script>-->
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>


    
<!--    <script>-->
<!--$(function() {  -->

<!--    jQuery.scrollSpeed(100, 600);-->

<!--});-->
<!--</script>-->
    

   
    
    <!--<iframe src="https://www.obiibot.chat/link.html?id=c2682c47-5e93-4585-b231-6482f5ee983b"  width="100%" height="600" frameBorder="0"></iframe>-->



<script>       
// Some random colors
// const colors = ["#3CC157", "#2AA7FF", "#9ebff2", "#FCBC0F", "#F85F36"];

// const numBalls = 10;
// const balls = [];

// for (let i = 0; i < numBalls; i++) {
//   let ball = document.createElement("div");
//   ball.classList.add("ball");
//   ball.style.background = colors[Math.floor(Math.random() * colors.length)];
//   ball.style.left = `${Math.floor(Math.random() * 100)}vw`;
//   ball.style.top = `${Math.floor(Math.random() * 100)}vh`;
//   ball.style.transform = `scale(${Math.random()})`;
//   ball.style.width = `${Math.random()}em`;
//   ball.style.height = ball.style.width;
  
//   balls.push(ball);
//   document.body.append(ball);
// }

// // Keyframes
// balls.forEach((el, i, ra) => {
//   let to = {
//     x: Math.random() * (i % 2 === 0 ? -11 : 11),
//     y: Math.random() * 12
//   };

//   let anim = el.animate(
//     [
//       { transform: "translate(0, 0)" },
//       { transform: `translate(${to.x}rem, ${to.y}rem)` }
//     ],
//     {
//       duration: (Math.random() + 1) * 2000, // random duration
//       direction: "alternate",
//       fill: "both",
//       iterations: Infinity,
//       easing: "ease-in-out"
//     }
//   );
// });
    
</script>  

<!--Start of Tawk.to Script-->
<!--<script type="text/javascript">-->
<!--var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();-->
<!--(function(){-->
<!--var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];-->
<!--s1.async=true;-->
<!--s1.src='https://embed.tawk.to/6144322525797d7a89ff6c2e/1ffp67otj';-->
<!--s1.charset='UTF-8';-->
<!--s1.setAttribute('crossorigin','*');-->
<!--s0.parentNode.insertBefore(s1,s0);-->
<!--})();-->
<!--</script>-->
<!--End of Tawk.to Script-->
    </body>

    </html>